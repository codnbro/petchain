Files from this directory was copied to level up directory 
==========================================================

Now all development will be on top level