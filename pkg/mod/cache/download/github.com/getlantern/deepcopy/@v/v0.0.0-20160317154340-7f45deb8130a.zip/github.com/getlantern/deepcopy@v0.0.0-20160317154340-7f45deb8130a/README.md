deepcopy [![Travis CI Status](https://travis-ci.org/getlantern/deepcopy.svg?branch=master)](https://travis-ci.org/getlantern/deepcopy)&nbsp;[![Coverage Status](https://coveralls.io/repos/getlantern/deepcopy/badge.png)](https://coveralls.io/r/getlantern/deepcopy)&nbsp;[![GoDoc](https://godoc.org/github.com/getlantern/deepcopy?status.png)](http://godoc.org/github.com/getlantern/deepcopy)
==========
deepcopy provides a basic implementation of deep copying using json.Marshal
and json.Unmarshal.  Hence it is not very performant, and it only works for
exported fields.

See [gopkg.in](http://gopkg.in/getlantern/deepcopy.v1) for usage and docs.